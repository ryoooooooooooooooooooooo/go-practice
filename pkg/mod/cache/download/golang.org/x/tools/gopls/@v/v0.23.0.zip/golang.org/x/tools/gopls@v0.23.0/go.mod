module golang.org/x/tools/gopls

go 1.26.0

require (
	github.com/fatih/gomodifytags v1.17.1-0.20250423142747-f3939df9aa3c
	github.com/fsnotify/fsnotify v1.9.0
	github.com/google/go-cmp v0.7.0
	github.com/google/jsonschema-go v0.4.3
	github.com/jba/templatecheck v0.7.1
	github.com/modelcontextprotocol/go-sdk v1.6.0
	golang.org/x/mod v0.37.0
	golang.org/x/net v0.56.0
	golang.org/x/sync v0.21.0
	golang.org/x/telemetry v0.0.0-20260625142307-59b4966ccb57
	golang.org/x/text v0.38.0
	golang.org/x/tools v0.47.1-0.20260707181000-a299dadba899
	golang.org/x/vuln v1.4.0
	gopkg.in/yaml.v3 v3.0.1
	honnef.co/go/tools v0.8.0-rc.1
	mvdan.cc/gofumpt v0.10.0
	mvdan.cc/xurls/v2 v2.6.0
)

require (
	github.com/BurntSushi/toml v1.6.0 // indirect
	github.com/fatih/camelcase v1.0.0 // indirect
	github.com/fatih/structtag v1.2.0 // indirect
	github.com/google/safehtml v0.1.0 // indirect
	github.com/segmentio/asm v1.2.1 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	golang.org/x/exp/typeparams v0.0.0-20260611194520-c48552f49976 // indirect
	golang.org/x/oauth2 v0.36.0 // indirect
	golang.org/x/sys v0.46.0 // indirect
	gopkg.in/check.v1 v1.0.0-20190902080502-41f04d3bba15 // indirect
)
